x = 3
if x == 3:
    # indented four spaces
    print("x is 3.")