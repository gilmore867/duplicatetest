x = 2
if x == 2:
    # indented four spaces
    print("x is 2.")